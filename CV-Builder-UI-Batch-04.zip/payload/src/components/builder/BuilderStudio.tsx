import { lazy, Suspense, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { FileText, Maximize2, Minimize2, Download, Plus, Copy, Trash2, X, Upload, CheckCircle2, SlidersHorizontal, Eye, ArrowLeft, Minus, Info, AlertCircle, Loader2, PencilLine, HardDrive, MoreHorizontal } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import { useAppStore } from '@/store/useAppStore';
import { cvProfileSchema } from '@/types/schema';
import { SectionWorkspace } from './SectionWorkspace';
import { ResumePaper } from './ResumePaper';
import { DesignPanel } from './DesignPanel';
import { essentials, fullName, hasUnsupportedPDFText, resumeBlocks, type SectionId } from './resumeModel';
import { useBuilderPersistence } from './useBuilderPersistence';
const PDFInspection = lazy(() => import('./PDFInspection'));
function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
function safeName(name: string) { return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim().slice(0, 80) || 'resume'; }
function Modal({ title, children, onClose, wide = false, design = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean; design?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { ref.current?.showModal(); return () => ref.current?.close(); }, []);
  return <dialog ref={ref} className={`studio-modal ${wide ? 'wide-modal' : ''} ${design ? 'design-sheet' : ''}`} onCancel={e => { e.preventDefault(); onClose(); }} onClick={e => { if (e.target === ref.current) { const r = ref.current.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) onClose(); } }} aria-label={title}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" aria-label="Close dialog" onClick={onClose}><X size={20} /></button></div>{children}</dialog>;
}
export function BuilderStudio() {
  const s = useAppStore();
  const { ready, status, message, retrySave } = useBuilderPersistence();
  const [section, setSection] = useState<SectionId>('personal');
  const [expanded, setExpanded] = useState<SectionId | null>(null);
  const [mobile, setMobile] = useState<'edit' | 'preview'>('edit');
  const [modal, setModal] = useState<'library' | 'pdf' | 'export' | 'design' | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [exporting, setExporting] = useState(false);
  const [previewFocused, setPreviewFocused] = useState(false);
  const [zoom, setZoom] = useState<number | null>(null);
  const [stageWidth, setStageWidth] = useState(700);
  const [paperHeight, setPaperHeight] = useState(1123);
  const stage = useRef<HTMLDivElement>(null);
  const paper = useRef<HTMLDivElement>(null);
  const importInput = useRef<HTMLInputElement>(null);
  const editor = useRef<HTMLDivElement>(null);
  const options = useRef<HTMLDetailsElement>(null);
  const profile = s.profiles.find(p => p.profileId === s.activeProfileId);
  const hasPreviewSection = profile ? (section === 'personal' || resumeBlocks(profile).some(b => b.id === section)) : false;
  const checklist = profile ? essentials(profile) : [];
  const fitWidth = Math.min(1, Math.max(0.2, (stageWidth - 48) / 794));
  const scale = zoom ?? fitWidth;
  const unsupportedPDF = profile ? hasUnsupportedPDFText(profile) : false;
  const selectedTemplate = ({ modern: 'Essential', classic: 'Editorial', minimal: 'Compact', split: 'Essential' })[s.documentTheme.layoutStyle];
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(''), 6500); return () => clearTimeout(t); } }, [toast]);
  useEffect(() => { const close = (e: PointerEvent) => { if (options.current && !options.current.contains(e.target as Node)) options.current.open = false; }; document.addEventListener('pointerdown', close); return () => document.removeEventListener('pointerdown', close); }, []);
  useLayoutEffect(() => {
    const a = stage.current; const b = paper.current;
    if (!a || !b) return;
    const measure = () => { if (a.clientWidth > 0 && a.clientHeight > 0 && b.scrollHeight > 0) { setStageWidth(a.clientWidth); setPaperHeight(b.scrollHeight); } };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(a); observer.observe(b);
    return () => observer.disconnect();
  }, [ready, profile?.profileId, mobile]);
  useEffect(() => { setSection('personal'); setExpanded(profile && !fullName(profile) ? 'personal' : null); setPreviewFocused(false); editor.current?.scrollTo({ top: 0 }); }, [profile?.profileId]);
  useEffect(() => {
    if (!hasPreviewSection || modal === 'design') return;
    const frame = requestAnimationFrame(() => {
      const container = stage.current;
      const target = paper.current?.querySelector<HTMLElement>(`[data-resume-section="${section}"]`);
      if (container && target) container.scrollTo({ top: Math.max(0, container.scrollTop + target.getBoundingClientRect().top - container.getBoundingClientRect().top - 24), behavior: 'instant' });
    });
    return () => cancelAnimationFrame(frame);
  }, [section, hasPreviewSection, scale, mobile]);
  const selectSection = (id: SectionId) => {
    setSection(id); setExpanded(id); setMobile('edit'); setPreviewFocused(false);
    requestAnimationFrame(() => {
      const container = editor.current;
      const row = container?.querySelector<HTMLElement>(`[data-section-card="${id}"]`);
      if (container && row) container.scrollTo({ top: container.scrollTop + row.getBoundingClientRect().top - container.getBoundingClientRect().top - 12, behavior: 'instant' });
    });
  };
  const showAdd = () => {
    setMobile('edit'); setPreviewFocused(false);
    requestAnimationFrame(() => { const node = document.getElementById('quick-add-sections'); const container = editor.current; if (node && container) container.scrollTo({ top: container.scrollTop + node.getBoundingClientRect().top - container.getBoundingClientRect().top - 16, behavior: 'instant' }); });
  };
  const newResume = () => { s.createProfile('Untitled resume'); setModal(null); selectSection('personal'); };
  const backup = () => {
    if (!profile) return;
    download(new Blob([JSON.stringify({ format: 'cv-builder-backup', version: 1, profile, theme: s.documentTheme }, null, 2)], { type: 'application/json' }), `${safeName(profile.profileName)}.json`);
    setToast('JSON backup downloaded. Keep it private: it contains your resume data.');
  };
  const importBackup = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > 5 * 1024 * 1024) throw new Error('Choose a JSON backup smaller than 5 MB.');
      const data = JSON.parse(await file.text());
      if (data.format !== 'cv-builder-backup' || data.version !== 1) throw new Error('Choose a JSON backup exported by this builder.');
      const parsed = cvProfileSchema.safeParse(data.profile);
      if (!parsed.success) throw new Error('The backup does not contain a valid resume. Your existing resumes are unchanged.');
      const imported = { ...parsed.data, profileId: uuid(), profileName: `${parsed.data.profileName} (Imported)` };
      // Import as a new document, never overwrite a current resume or its theme.
      useAppStore.setState(state => ({ profiles: [...state.profiles, imported], activeProfileId: imported.profileId }));
      setModal(null); selectSection('personal'); setToast('Resume imported as a new document.');
    } catch (e) { setToast(e instanceof Error ? e.message : 'Could not import this backup.'); }
    finally { if (importInput.current) importInput.current.value = ''; }
  };
  const exportPDF = async () => {
    if (!profile || exporting) return;
    if (!fullName(profile)) { setModal(null); selectSection('personal'); setToast('Add your name before exporting your resume.'); return; }
    // The built-in PDF fonts do not support Arabic/CJK. Never silently emit missing glyphs.
    if (unsupportedPDF) { setModal(null); setToast('This release uses Latin PDF fonts. Arabic and other non-Latin PDF export needs a dedicated font/shaping pass; your content is saved and can be backed up as JSON.'); return; }
    setExporting(true);
    try {
      const [{ pdf }, { BuilderPDF }] = await Promise.all([import('@react-pdf/renderer'), import('./BuilderPDF')]);
      const blob = await pdf(<BuilderPDF profile={profile} theme={s.documentTheme} />).toBlob();
      download(blob, `${safeName(fullName(profile) || profile.profileName)}_Resume.pdf`);
      setToast('Your PDF is ready. Check the final page breaks before sending it.');
      setModal(null);
    } catch { setModal(null); setToast('Could not generate the PDF. Your resume is unchanged. Try again or download a JSON backup.'); }
    finally { setExporting(false); }
  };
  if (!ready) return <div className="builder-loading"><div className="brand"><span className="brand-mark"><FileText size={22} /></span>folio<span className="brand-dot">.</span></div>{status === 'error' ? <><AlertCircle size={24} /><h1>We couldn’t open your workspace.</h1><p>{message}</p><button className="primary-button" onClick={() => window.location.reload()}>Reload and retry</button></> : <><Loader2 className="spin" size={24} /><p>Opening your workspace…</p></>}</div>;
  return <div className="builder-app clean-builder">
    <header className="studio-topbar clean-topbar">
      <button className="resume-back" onClick={() => setModal('library')} aria-label="My resumes"><ArrowLeft size={19} /><span>My resumes</span></button>
      <div className="clean-document">{profile ? <input className="document-title" aria-label="Resume document name" value={profile.profileName} maxLength={100} onChange={e => s.updateProfileName(profile.profileId, e.target.value)} onBlur={e => { if (!e.target.value.trim()) s.updateProfileName(profile.profileId, 'Untitled resume'); }} /> : <strong>Your resume workspace</strong>}<div className={`save-state ${status === 'error' ? 'save-error' : ''}`} role="status">{status === 'saved' ? <CheckCircle2 size={12} /> : status === 'saving' ? <Loader2 size={12} className="spin" /> : <AlertCircle size={12} />}<span>{status === 'saved' ? 'Saved on this device' : status === 'saving' ? 'Saving changes…' : 'Not saved'}</span>{status === 'error' && <button onClick={retrySave}>Retry</button>}</div></div>
      <div className="clean-header-actions"><details className="document-options" ref={options} onKeyDown={e => { if (e.key === 'Escape') { e.preventDefault(); if (options.current) { options.current.open = false; options.current.querySelector('summary')?.focus(); } } }}><summary aria-label="More document actions" title="More document actions"><MoreHorizontal size={20} /></summary><div className="document-options-menu"><button disabled={!profile} onClick={() => { if (options.current) options.current.open = false; backup(); }}><Download size={17} />Download JSON backup</button><button onClick={() => { if (options.current) options.current.open = false; importInput.current?.click(); }}><Upload size={17} />Import JSON backup</button><p>Resumes are stored in this browser. Keep a backup of important work.</p></div></details><button className="primary-button clean-export" aria-label="Export PDF" disabled={!profile || exporting} onClick={() => setModal('export')}>{exporting ? <Loader2 size={17} className="spin" /> : <Download size={17} />}<span>Export PDF</span></button></div>
    </header>
    {message && <div className="storage-warning" role="alert"><AlertCircle size={16} />{message}</div>}
    {!profile ? <main className="no-resumes"><span className="empty-plus"><FileText size={30} /></span><span className="eyebrow">A FRESH START</span><h1>Your next chapter starts here.</h1><p>Build a clear, thoughtful resume. One section at a time.</p><button className="primary-button" onClick={newResume}><Plus size={18} />Create a resume</button><button className="text-button" onClick={() => importInput.current?.click()}>Import a JSON backup</button></main> : <>
      <div className="mobile-workspace-tabs"><button className={mobile === 'edit' ? 'active' : ''} onClick={() => { setMobile('edit'); setPreviewFocused(false); }}><PencilLine size={16} /> Edit resume</button><button className={mobile === 'preview' ? 'active' : ''} onClick={() => setMobile('preview')}><Eye size={16} /> Live preview</button></div>
      <main className={`studio-workspace clean-workspace mobile-${mobile} ${previewFocused ? 'preview-focused' : ''}`}>
        <section className="editor-pane" aria-label="Resume editor"><div className="clean-editor-heading"><h1>Resume content</h1><button className="text-button" onClick={showAdd}><Plus size={17} />Add section</button></div><div className="editor-scroll" ref={editor}><SectionWorkspace key={profile.profileId} profile={profile} expanded={expanded} onExpand={setExpanded} onSelect={setSection} /></div></section>
        <section className="preview-pane" aria-label="Resume preview workspace"><div className="preview-stage" ref={stage}><div className="scaled-paper" style={{ width: 794 * scale, height: paperHeight * scale }}><div ref={paper} style={{ width: 794, transform: `scale(${scale})`, transformOrigin: 'top left' }}><ResumePaper profile={profile} theme={s.documentTheme} onEdit={selectSection} /></div></div><p className="preview-footnote">Live preview · Open PDF preview to check page breaks</p></div><footer className="preview-toolbar clean-preview-toolbar"><button className="text-button design-trigger" onClick={() => setModal('design')}><SlidersHorizontal size={17} />Design<span className="toolbar-template">{selectedTemplate}</span></button><div className="zoom-controls"><button className="icon-button" aria-label="Zoom out" onClick={() => { setZoom(Math.max(0.15, scale - 0.1)); }}><Minus size={16} /></button><span>{Math.round(scale * 100)}%</span><button className="icon-button" aria-label="Zoom in" onClick={() => { setZoom(Math.min(1.4, scale + 0.1)); }}><Plus size={16} /></button><button className={`text-button ${zoom === null ? 'fit-active' : ''}`} onClick={() => { setZoom(null); }} aria-label="Fit preview to width">Fit</button></div><div className="preview-file-actions"><button className="text-button pdf-trigger" aria-label="PDF preview" title="PDF preview" onClick={() => setModal('pdf')}><Eye size={17} /><span>PDF preview</span></button><button className="icon-button desktop-only" aria-label={previewFocused ? 'Exit focus preview' : 'Focus preview'} title={previewFocused ? 'Return to editor' : 'Focus preview'} onClick={() => { setPreviewFocused(!previewFocused); setMobile('preview'); }}>{previewFocused ? <Minimize2 size={17} /> : <Maximize2 size={17} />}</button></div></footer></section>
      </main>
    </>}
    <input ref={importInput} type="file" accept=".json,application/json" hidden onChange={e => void importBackup(e.target.files?.[0])} />
    {modal === 'design' && profile && <Modal title="Design & template" design onClose={() => setModal(null)}><div className="design-sheet-body"><DesignPanel /></div><div className="design-sheet-footer"><button className="primary-button" onClick={() => setModal(null)}>Done</button></div></Modal>}
    {modal === 'library' && <Modal title="My resumes" onClose={() => { setModal(null); setDeleting(null); }}><div className="library-intro"><p>A workspace for every next step.</p><button className="primary-button" onClick={newResume}><Plus size={16} />New resume</button></div><div className="resume-library">{s.profiles.map(p => <div key={p.profileId} className={`library-card ${s.activeProfileId === p.profileId ? 'selected' : ''}`}><FileText size={24} /><button className="library-open" onClick={() => { s.setActiveProfile(p.profileId); setModal(null); selectSection('personal'); }}><strong>{p.profileName || 'Untitled resume'}</strong><span>{fullName(p) || 'Add your personal details'}{s.activeProfileId === p.profileId ? ' · Current document' : ''}</span></button><button className="icon-button" aria-label={`Duplicate ${p.profileName}`} onClick={() => { s.cloneProfile(p.profileId, `${p.profileName} (Copy)`); setToast('Resume duplicated.'); }}><Copy size={17} /></button><button className="icon-button danger-text" aria-label={`Delete ${p.profileName}`} onClick={() => setDeleting(p.profileId)}><Trash2 size={17} /></button>{deleting === p.profileId && <div className="delete-confirm"><p>Delete this resume from this device? Download a backup first if you need it.</p><button className="secondary-button" onClick={() => setDeleting(null)}>Keep resume</button><button className="danger-button" onClick={() => { s.deleteProfile(p.profileId); setDeleting(null); }}>Delete resume</button></div>}</div>)}{!s.profiles.length && <p className="subtle-note">No resumes yet. Start with a blank document or import a backup.</p>}</div><div className="library-bottom"><button className="text-button" onClick={() => { s.loadSampleProfile(); setModal(null); selectSection('personal'); setToast('Demo resume loaded. Replace the sample information with your own.'); }}><FileText size={16} />Try a demo resume</button><button className="text-button" onClick={() => importInput.current?.click()}><Upload size={16} />Import JSON backup</button></div><p className="library-privacy"><HardDrive size={14} />Stored in this browser. Clearing browser data can remove resumes; keep backups.</p></Modal>}
    {modal === 'export' && profile && <Modal title="Ready for your next chapter?" onClose={() => setModal(null)}><div className="export-dialog"><div className="export-art"><FileText size={42} /><CheckCircle2 size={22} /></div><h3>A polished resume. A portable PDF.</h3><p>Export your <strong>{selectedTemplate}</strong> template on A4 paper, with selectable text and no watermark.</p><div className="export-checklist">{checklist.map(x => <div key={x.label}>{x.done ? <CheckCircle2 size={16} /> : <Info size={16} />}<span>{x.label}</span><small>{x.done ? 'Included' : 'Not added'}</small></div>)}</div><p className="subtle-note">Optional sections can stay empty. This is a content checklist, not a guarantee of job or ATS outcomes. Latin-script PDF export in this release.</p><button className="primary-button export-main" disabled={exporting} onClick={() => void exportPDF()}>{exporting ? <Loader2 className="spin" size={18} /> : <Download size={18} />}{exporting ? 'Preparing PDF…' : 'Download PDF'}</button><div className="export-secondary"><button className="text-button" onClick={() => setModal('pdf')}><Eye size={16} />Inspect PDF first</button><button className="text-button" onClick={backup}><Download size={16} />Save JSON backup</button></div></div></Modal>}
    {modal === 'pdf' && profile && <Modal title="PDF preview · Final page breaks" wide onClose={() => setModal(null)}><div className="pdf-preview-note"><Info size={16} />Preview of the file you will download. Latin-script fonts in this release.<button className="text-button" disabled={exporting} onClick={() => void exportPDF()}><Download size={16} />Download</button></div><Suspense fallback={<div className="pdf-loading"><Loader2 className="spin" size={24} />Preparing your PDF…</div>}>{unsupportedPDF ? <div className="pdf-loading">Non-Latin PDF export needs dedicated fonts and shaping. Your content is saved; use JSON backup for now.</div> : <PDFInspection profile={profile} theme={s.documentTheme} />}</Suspense></Modal>}
    {toast && <div className="builder-toast" role="status"><Info size={18} /><span>{toast}</span><button className="icon-button" aria-label="Dismiss notification" onClick={() => setToast('')}><X size={16} /></button></div>}
  </div>;
}
